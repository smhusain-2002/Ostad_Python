class Car:
    def __init__(self):
        self.brand = ""
        self.model = ""
        self.numberseat = 0
        self.numberdoor = 0
        self.color = ""
        self.manufyr = 0


    # def __init__(self, brand, numberseat, numberdoor, color, manufyr):
        self.brand = "Toyota"
        self.color = "Silver"
        self.manufyr = "2013"
        self.numberdoor = 4
        self.numberseat = 7
        self.model = "Rush"


car1 = Car()
print ( "Car Brand Name: ", car1.brand )
car1.brand = "Toyota"
print ( "Car Brand Name: ", car1.brand )